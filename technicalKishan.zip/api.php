<?php

error_reporting(0);

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json");

header("Access-Control-Allow-Methods: POST, GET");

$databaseFile = 'database.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $input = file_get_contents('php://input');

    if ($input) {

        if(file_put_contents($databaseFile, $input)){

            echo json_encode(["status" => "success", "message" => "Data Saved Successfully"]);

        } else {

            echo json_encode(["status" => "error", "message" => "Permission Denied. Check folder permissions."]);

        }

    }

} else {

    if (file_exists($databaseFile)) {

        echo file_get_contents($databaseFile);

    } else {

        // Default data with NEW features (apks, custom_links)

        $defaultData = [

            "posts" => [],

            "apks" => [], 

            "custom_links" => [], 

            "videos" => [],

            "ads" => ["header"=>"", "sidebar"=>"", "footer"=>""],

            "socials" => ["yt"=>"", "fb"=>"", "ig"=>"", "tg"=>""],

            "categories" => ["Tech", "Updates"]

        ];

        echo json_encode($defaultData);

    }

}

?>
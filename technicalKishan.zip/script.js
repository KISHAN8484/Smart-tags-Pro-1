// 1. Dark Mode Toggle with LocalStorage
function toggleDarkMode() {
    const body = document.body;
    const icon = document.getElementById('mode-icon');
    
    body.classList.toggle('dark-mode');
    
    // Icon Switch
    if(body.classList.contains('dark-mode')) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
        localStorage.setItem('theme', 'dark');
    } else {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
        localStorage.setItem('theme', 'light');
    }
}

// Check Saved Theme on Load
window.onload = function() {
    const savedTheme = localStorage.getItem('theme');
    const icon = document.getElementById('mode-icon');
    
    if(savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
    }
    
    // Load Admin Posts
    loadPosts();
}

// 2. Mobile Menu Toggle
function toggleMobileMenu() {
    const menu = document.getElementById('nav-menu');
    menu.classList.toggle('active');
}

// 3. Search Overlay
function toggleSearch() {
    const overlay = document.getElementById('search-overlay');
    if(overlay.style.display === 'flex') {
        overlay.style.display = 'none';
    } else {
        overlay.style.display = 'flex';
    }
}

// 4. Back to Top
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 5. Load Posts from Admin Panel (Simulated)
function loadPosts() {
    const container = document.getElementById('posts-container');
    // Use 'stp_posts' key from your previous Admin Panel code
    let posts = JSON.parse(localStorage.getItem('stp_posts')) || [];

    if (posts.length > 0) {
        // Clear sample post only if we have real posts
        container.innerHTML = ''; 
        
        posts.reverse().forEach(post => {
            let imageSrc = post.image ? post.image : 'https://via.placeholder.com/500x300';
            
            let html = `
                <article class="post-card">
                    <div class="thumb">
                        <span class="category-tag">${post.category || 'General'}</span>
                        <img src="${imageSrc}" alt="${post.title}">
                    </div>
                    <div class="details">
                        <div class="meta">
                            <span><i class="far fa-user"></i> Admin</span>
                            <span><i class="far fa-clock"></i> Today</span>
                        </div>
                        <h3><a href="#">${post.title}</a></h3>
                        <p>${post.desc.substring(0, 100)}...</p>
                        <a href="#" class="read-btn">Read More</a>
                    </div>
                </article>
            `;
            container.innerHTML += html;
        });
    }
}